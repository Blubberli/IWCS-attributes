training data:
contains three subdirectories, one for each of the three split that were used for the experiments. 
each split contains 3 training data for the small augmented dataset (small.txt, small_head_overlap.txt, small_mod_overlap.txt) and 3 training data for the large augmented dataset (large.txt, large_head_overlap.txt, large_mod_overlap.txt)
each line is separated by white spaces denoting the following:
adjective noun attribute
validation data:
each split contains one validation set (val.txt), each line separated by whitespaces but additionally having a fourth column with "status" which denotes whether the adj-noun phrase is a collocation or a free phrase.
test data:
each split contains one validation set (test.txt), each line separated by whitespaces but additionally having a fourth column with "status" which denotes whether the adj-noun phrase is a collocation or a free phrase.
gold standard:
the original, manually annotated dataset with adjective-noun phrases, the sense ID of GermaNet for the adjective, the sense ID of GermaNet for the noun (not that this can be empty '--' if for example the sense was not modelled in GermaNet), the status (free phrase, collocation) and one of 16 possible attributes. 

